import { useEffect, useRef, useState } from 'react'

const topics = [
  'Should students be allowed to use AI tools for homework?',
  'Should smartphones be allowed in classrooms?',
  'Should schools teach financial literacy?',
  'Should social media be limited for teenagers?',
  'Should homework be reduced for high school students?',
]

type Message = { who: 'coach' | 'you'; text: string }
type Analysis = { claim: boolean; evidence: boolean; reasoning: boolean; rebuttal: boolean }

const analyze = (text: string): Analysis => ({
  claim: /\b(i think|i believe|in my opinion|should|should not|must)\b/i.test(text),
  evidence: /\b(because|for example|for instance|such as|according to|research|data|experience)\b/i.test(text),
  reasoning: /\b(this shows|this means|as a result|therefore|so that|this suggests|if .* then)\b/i.test(text),
  rebuttal: /\b(however|some people|on the other hand|although|even though|but others|critics)\b/i.test(text),
})

const nextQuestion = (a: Analysis) => {
  if (!a.claim) return 'What is your clear position? Try beginning with “I believe that…”'
  if (!a.evidence) return 'Clear claim. What specific example, fact, or experience supports it?'
  if (!a.reasoning) return 'Good example. Why does it prove your claim? Try “This shows that…”'
  if (!a.rebuttal) return 'What might someone on the other side say, and how would you respond?'
  return 'Strong work. Add one more concrete example to make your case even better.'
}

export default function App() {
  const [mode, setMode] = useState('hybrid')
  const [topicMode, setTopicMode] = useState<'popular' | 'custom'>('popular')
  const [topic, setTopic] = useState(topics[0])
  const [customTopic, setCustomTopic] = useState('')
  const [level, setLevel] = useState('B1')
  const [answer, setAnswer] = useState('')
  const [messages, setMessages] = useState<Message[]>([
    { who: 'coach', text: 'Choose a topic and share your first argument. I’ll help you build it step by step.' },
  ])
  const [round, setRound] = useState(0)
  const [result, setResult] = useState<{ score: number; analysis: Analysis } | null>(null)
  const [status, setStatus] = useState('Ready when you are.')
  const [recording, setRecording] = useState(false)
  const chatRef = useRef<HTMLDivElement>(null)
  const recognitionRef = useRef<any>(null)
  const currentTopic = topicMode === 'custom' ? customTopic.trim() : topic

  useEffect(() => {
    chatRef.current?.scrollTo({ top: chatRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages])

  const speak = (text: string) => {
    if (!('speechSynthesis' in window)) return
    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = 'en-US'
    utterance.rate = 0.95
    window.speechSynthesis.speak(utterance)
  }

  const toggleRecording = () => {
    if (recording) return recognitionRef.current?.stop()
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    if (!SpeechRecognition) return setStatus('Voice input works best in Chrome.')
    const recognition = new SpeechRecognition()
    recognition.lang = 'en-US'
    recognition.interimResults = true
    recognition.onresult = (event: any) => {
      let transcript = ''
      for (const item of event.results) transcript += `${item[0].transcript} `
      setAnswer(transcript.trim())
    }
    recognition.onend = () => {
      setRecording(false)
      setStatus('Recording complete. Review your answer, then send it.')
    }
    recognition.onerror = () => {
      setRecording(false)
      setStatus('We could not access the microphone. Try typing instead.')
    }
    recognitionRef.current = recognition
    setRecording(true)
    setStatus('Listening… speak your argument in English.')
    recognition.start()
  }

  const send = () => {
    const text = answer.trim()
    if (!currentTopic) return setStatus('Add a topic before you begin.')
    if (text.split(/\s+/).length < 6) return setStatus('Add a little more detail before sending.')
    const analysis = analyze(text)
    const nextRound = round + 1
    setMessages((old) => [...old, { who: 'you', text }])
    setAnswer('')
    setRound(nextRound)
    if (nextRound >= 4 || (Object.values(analysis).every(Boolean) && nextRound >= 3)) {
      const score = Math.round(45 + Object.values(analysis).filter(Boolean).length * 13.75)
      const feedback =
        score >= 85
          ? `Excellent work. Your final score is ${score}/100 — your argument is clear and complete.`
          : `Your final score is ${score}/100. Next time, make your evidence more specific.`
      setResult({ score, analysis })
      setMessages((old) => [...old, { who: 'coach', text: feedback }])
      speak(feedback)
    } else {
      const question = nextQuestion(analysis)
      setMessages((old) => [...old, { who: 'coach', text: question }])
      speak(question)
    }
    setStatus('Nice work — keep building your case.')
  }

  const restart = () => {
    setRound(0)
    setResult(null)
    setAnswer('')
    setMessages([{ who: 'coach', text: 'New round. Choose a topic, take a side, and make your case.' }])
    setStatus('Ready when you are.')
  }

  return (
    <main className="page-shell">
      <header className="topbar">
        <a className="brand" href="#" aria-label="ArguMate home">
          <i>A</i><strong>Argu<span>MATE</span></strong>
        </a>
        <nav><a href="#practice">Features</a><a href="#how">Method</a><a href="#practice">Try the app</a></nav>
        <a className="download-link" href="/argumate-full.html" download>Download HTML</a>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <div className="hero-badge">Free argument practice</div>
          <h1>Speak clearly.<br />Argue <span>confidently.</span></h1>
          <div className="accent-line" />
          <p>Practice English arguments with an adaptive coach. Build a clear claim, add evidence, and learn how to answer the other side.</p>
          <div className="hero-actions">
            <a className="hero-input" href="#practice">Choose a topic to practice...</a>
            <a className="hero-cta" href="#practice">Start practicing <b>→</b></a>
          </div>
          <small>No account needed · Voice and text practice</small>
        </div>
        <div className="hero-visual" aria-label="ArguMate app preview">
          <div className="glow" />
          <div className="phone">
            <div className="phone-top"><span>9:41</span><i /></div>
            <div className="phone-brand"><b>ARGU<span>MATE</span></b><small>Practice room</small></div>
            <div className="phone-topic"><small>TODAY’S QUESTION</small><b>Should students use AI for homework?</b></div>
            <div className="mini-message coach"><small>ARGUMATE</small><p>What is your clear position?</p></div>
            <div className="mini-message me"><small>YOU</small><p>I believe students should use AI because it can help them learn.</p></div>
            <div className="phone-score"><span>Argument strength</span><b>72%</b><i /></div>
            <div className="phone-nav"><span>Practice</span><span>Progress</span><span>Tips</span></div>
          </div>
          <div className="float-card card-claim"><i>01</i><div><b>Clear claim</b><small>Position detected</small></div></div>
          <div className="float-card card-evidence"><i>02</i><div><b>Evidence</b><small>Add an example</small></div></div>
          <div className="float-card card-feedback"><i>03</i><div><b>Smart feedback</b><small>Made for your level</small></div></div>
        </div>
      </section>

      <section className="workspace" id="practice">
        <div className="panel setup-panel">
          <div className="panel-heading">
            <span className="step">01</span>
            <div><h2>Pick your side</h2><p>Choose your setup, then start arguing.</p></div>
          </div>

          <FieldLabel>How do you want to answer?</FieldLabel>
          <div className="mode-grid">
            {['text', 'voice', 'hybrid'].map((item, i) => (
              <button key={item} className={`choice choice-${i + 1} ${mode === item ? 'active' : ''}`} onClick={() => setMode(item)}>
                <b>{item}</b><small>{item === 'text' ? 'Type it out' : item === 'voice' ? 'Say it aloud' : 'Use both'}</small>
              </button>
            ))}
          </div>

          <FieldLabel>Choose a topic</FieldLabel>
          <div className="switcher">
            <button className={topicMode === 'popular' ? 'active' : ''} onClick={() => setTopicMode('popular')}>Popular</button>
            <button className={topicMode === 'custom' ? 'active' : ''} onClick={() => setTopicMode('custom')}>My own</button>
          </div>
          {topicMode === 'popular' ? (
            <select value={topic} onChange={(e) => setTopic(e.target.value)}>{topics.map((item) => <option key={item}>{item}</option>)}</select>
          ) : (
            <input value={customTopic} onChange={(e) => setCustomTopic(e.target.value)} placeholder="Type your own topic in English" />
          )}

          <FieldLabel>English level</FieldLabel>
          <div className="level-row">
            {['A2', 'B1', 'B2'].map((item) => <button key={item} className={level === item ? 'active' : ''} onClick={() => setLevel(item)}>{item}</button>)}
          </div>

          {mode !== 'text' && (
            <div className="voice-box">
              <div><b>Voice input</b><small>{status}</small></div>
              <button className={recording ? 'recording' : ''} onClick={toggleRecording}>{recording ? 'Stop' : 'Record'}</button>
              <button onClick={() => speak(`Here is your discussion question: ${currentTopic || 'choose a topic first'}`)}>Listen</button>
            </div>
          )}

          <FieldLabel>Your argument</FieldLabel>
          <textarea value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder="I believe that… because… For example… However… Therefore…" />
          <div className="send-row"><span>{answer.trim() ? answer.trim().split(/\s+/).length : 0} words</span><button className="primary" onClick={send} disabled={!!result}>Send my argument</button></div>
          <p className="status-line" aria-live="polite">{status}</p>
        </div>

        <div className="panel chat-panel" id="coach">
          <div className="panel-heading">
            <span className="step blue">02</span>
            <div><h2>Build your case</h2><p>Your coach responds to what you say.</p></div>
          </div>
          <div className="topic-ticket">
            <span>Today’s debate</span><b>{currentTopic || 'Your custom topic will appear here.'}</b>
          </div>
          <div className="chat" ref={chatRef}>
            {messages.map((message, index) => (
              <article className={`message ${message.who}`} key={`${message.who}-${index}`}>
                <small>{message.who === 'coach' ? 'ARGUMATE' : 'YOU'}</small>
                <p>{message.text}</p>
              </article>
            ))}
          </div>
          {result ? (
            <div className="score-card">
              <div><span>FINAL SCORE</span><strong>{result.score}<small>/100</small></strong></div>
              <div className="skills">{Object.entries(result.analysis).map(([name, ok]) => <span className={ok ? 'ok' : ''} key={name}>{name}</span>)}</div>
              <button onClick={restart}>Start a new practice</button>
            </div>
          ) : (
            <div className="coach-note"><b>Coach’s tip</b><p>A strong argument connects every example back to the main claim.</p></div>
          )}
        </div>
      </section>

      <section className="how" id="how">
        <p className="eyebrow">THE FORMULA</p><h2>Four moves. One strong argument.</h2>
        <div>{['Say what you think', 'Show your evidence', 'Explain the link', 'Answer the other side'].map((text, i) => <article key={text}><span>0{i + 1}</span><h3>{['Claim', 'Evidence', 'Reasoning', 'Rebuttal'][i]}</h3><p>{text}</p></article>)}</div>
      </section>
      <footer className="profile-footer">
        <div className="footer-grid">
          <section className="founder">
            <p className="footer-label">Meet the creator</p>
            <div className="founder-info">
              <img src="/shifa-profile.png" alt="Shifa Aulyya" />
              <div>
                <blockquote>“I built ArguMate to help English learners express their ideas clearly and argue with confidence.”</blockquote>
                <strong>SHIFA AULYYA</strong>
              </div>
            </div>
          </section>
          <section>
            <p className="footer-label">Explore</p>
            <a href="#practice">Practice</a>
            <a href="#coach">Coaching chat</a>
            <a href="#how">The method</a>
          </section>
          <section>
            <p className="footer-label">The method</p>
            <span>Claim</span>
            <span>Evidence</span>
            <span>Reasoning</span>
            <span>Rebuttal</span>
          </section>
          <section className="contact">
            <p className="footer-label">Get in touch</p>
            <p>Have a question, idea, or feedback? Send me an email.</p>
            <a className="email-pill" href="mailto:shifaaulyya@gmail.com">
              <i>@</i> shifaaulyya@gmail.com
            </a>
          </section>
        </div>
        <div className="footer-bottom">
          <b>ARGU<span>MATE</span></b>
          <p>© 2026 ArguMate. Think first. Argue better.</p>
        </div>
      </footer>
    </main>
  )
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return <label className="field-label">{children}</label>
}
